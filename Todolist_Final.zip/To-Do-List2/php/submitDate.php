<?php
include("connect.php");
$id = $_POST["id"];
$valueDate = $_POST["date"];

$sql = "UPDATE task SET deadline = '".$valueDate."' WHERE ID='".$id."'";

$query = mysqli_query($conn, $sql);
header("Location:/To-Do-List2/to-do-list2.php");
mysqli_close($conn);
?>
<?php
include("connect.php");
$id = $_POST["id"];

$sql = "UPDATE task SET status = 0 WHERE ID='".$id."'";

$query = mysqli_query($conn, $sql);
header("Location:/To-Do-List2/to-do-list2.php");
mysqli_close($conn);
?>
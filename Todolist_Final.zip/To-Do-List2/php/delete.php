<?php
include("connect.php");
$id = $_POST["id"];

$sql = "DELETE FROM task WHERE ID = '".$_POST["id"]."' ";

$query = mysqli_query($conn, $sql);
header("Location:/To-Do-List2/to-do-list2.php");
mysqli_close($conn);
?>
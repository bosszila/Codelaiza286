<?php
include("connect.php");
$id = $_POST["id"];
$valueNote = $_POST["note"];

$sql = "UPDATE task SET detail = '".$valueNote."' WHERE ID='".$id."'";

$query = mysqli_query($conn, $sql);
header("Location:/To-Do-List2/to-do-list2.php");
mysqli_close($conn);
?>
<?php
include("connect.php");
$id = $_POST["id"];
$valuePriority = $_POST["priority"];

$sql = "UPDATE task SET priority = '".$valuePriority."' WHERE ID='".$id."'";

$query = mysqli_query($conn, $sql);
header("Location:/To-Do-List2/to-do-list2.php");
mysqli_close($conn);
?>
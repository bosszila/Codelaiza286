<?php
$host = "localhost";
$user = "root";
$passwd = "";
$db = "todolist";

$conn = new mysqli($host, $user, $passwd, $db);
mysqli_set_charset($conn,"utf8");
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 


?>
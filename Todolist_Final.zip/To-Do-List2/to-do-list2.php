<?php
include("php/connect.php");
$sql_complete = "SELECT * FROM `task` WHERE status = 1 ORDER BY Priority ASC";
$sql_incomplete = "SELECT * FROM `task` WHERE status = 0 ORDER BY Priority ASC";

$q_comp = mysqli_query($conn, $sql_complete);
$q_incomp = mysqli_query($conn, $sql_incomplete);
?>

<html>
    <head>
    <title>Todo List</title>
         <link rel="stylesheet" href="css-to-do-list.css">
          <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
          <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.6.4/angular.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.6.4/angular.min.js"></script>
      <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
      <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
   
        <style>
        </style>
    </head>
<body>

    <div class="container">
      <p>
          <label for="new-task">Add Item</label>
          <form action="php/insert.php" method="post">
            <input id="new-task" type="text" name="issue">
            <input class="btn btn-info" type="submit" value="Add">
        </form>
      </p>

        
    <h3>Todo</h3>
    <ul id="incomplete-tasks">
      <?php
      
      $nowDate = date("Y-m-d");
        while($row = mysqli_fetch_array($q_incomp,MYSQLI_NUM)){
            echo '<li> 

            <form method="POST" action="php/setDone.php">
            <input type="hidden" name="id" value="'.$row[0].'">
            <input type="submit" value="done">
            </form>

            <label>'.$row[1].'</label>
            <input type="text"  value="'.$row[3].'">
            <input type="button" value="Edit">

            <form method="POST" action="php/submitNote.php">
            <input type="hidden" name="id" value="'.$row[0].'">
            <input name="note" value='.$row[2].'>
            <input type="submit" value="Note">
            </form>

            <form method="POST" action="php/submitDate.php">
            <input type="hidden" name="id" value="'.$row[0].'">
            <input name="date" type="date" min='.$nowDate.' value='.$row[4].'>
            <input type="submit" value="Date" class="delete">
            </form>

            <form method="POST" action="php/delete.php">
            <input type="hidden" name="id" value="'.$row[0].'">
            <input type="submit" value="delete" class="delete">
            </form>

            <form method="POST" action="php/setPriority.php" id="boss1">
            <input type="hidden" name="id" value="'.$row[0].'">
            <select name="priority" form="boss1">';

            if($row[5] == 1){
            echo  '<option value="1" selected> 1 </option>
            <option value="2"> 2 </option>
            <option value="3"> 3 </option>
            <option value="4"> 4 </option>
            <option value="5"> 5 </option>';
            }
            if($row[5] == 2){
             echo  '<option value="1" > 1 </option>
                <option value="2" selected > 2 </option>
                <option value="3"> 3 </option>
                <option value="4"> 4 </option>
                <option value="5"> 5 </option>';
                }
                if($row[5] == 3){
                    echo  '<option value="1" > 1 </option>
                    <option value="2"> 2 </option>
                    <option value="3" selected> 3 </option>
                    <option value="4"> 4 </option>
                    <option value="5"> 5 </option>';
                    }
                    if($row[5] == 4){
                        echo  '<option value="1"> 1 </option>
                        <option value="2"> 2 </option>
                        <option value="3"> 3 </option>
                        <option value="4" selected> 4 </option>
                        <option value="5"> 5 </option>';
                        }
                        if($row[5] == 5){
                            echo  '<option value="1" > 1 </option>
                            <option value="2"> 2 </option>
                            <option value="3"> 3 </option>
                            <option value="4"> 4 </option>
                            <option value="5" selected> 5 </option>';
                            }
                            echo 
              
               '</select>
               <input type="submit" value="SetPriority"> 
            </form>
            
            <input type="hidden" value="'.$row[0].'">
            </li>';
        }
    
      ?>
      </ul>

     
      <?php
      if(mysqli_num_rows($q_comp) != 0){
        echo '<h3>Done</h3>';
        echo '<ul id="incomplete-tasks">';
    
       $nowDate = date("Y-m-d");
        while($row = mysqli_fetch_array($q_comp,MYSQLI_NUM)){
            
            echo '<li>

            <form method="POST" action="php/setNotDone.php">
            <input type="hidden" name="id" value="'.$row[0].'">
            <input type="submit" value="Notdone">
            </form>


            <label>'.$row[1].'</label>
            <input type="text"  value="'.$row[3].'">
            <input type="button" value="Edit">
            
           
            <form method="POST" action="php/submitNote.php">
            <input type="hidden" name="id" value="'.$row[0].'">
            <input name="note" value='.$row[2].'>
            <input type="submit" value="Note">
            </form>

            <form method="POST" action="php/submitDate.php">
            <input type="hidden" name="id" value="'.$row[0].'">
            <input name="date" type="date" min='.$nowDate.' value='.$row[4].'>
            <input type="submit" value="Date" class="delete">
            </form>

             <form method="POST" action="php/delete.php">
            <input type="hidden" name="id" value="'.$row[0].'">
            <input type="submit" value="delete" class="delete">
            </form>

           
            <form method="POST" action="php/setPriority.php" id="boss">
            <input type="hidden" name="id" value="'.$row[0].'">
            <select name="priority" placeholder="select priority" form="boss">';

            if($row[5] == 1){
            echo  '<option value="1" selected> 1 </option>
            <option value="2"> 2 </option>
            <option value="3"> 3 </option>
            <option value="4"> 4 </option>
            <option value="5"> 5 </option>';
            }
            if($row[5] == 2){
                echo  '<option value="1" > 1 </option>
                <option value="2" selected > 2 </option>
                <option value="3"> 3 </option>
                <option value="4"> 4 </option>
                <option value="5"> 5 </option>';
                }
                if($row[5] == 3){
                    echo  '<option value="1" > 1 </option>
                    <option value="2"> 2 </option>
                    <option value="3" selected> 3 </option>
                    <option value="4"> 4 </option>
                    <option value="5"> 5 </option>';
                    }
                    if($row[5] == 4){
                        echo  '<option value="1"> 1 </option>
                        <option value="2"> 2 </option>
                        <option value="3"> 3 </option>
                        <option value="4" selected> 4 </option>
                        <option value="5"> 5 </option>';
                        }
                        if($row[5] == 5){
                            echo  '<option value="1" > 1 </option>
                            <option value="2"> 2 </option>
                            <option value="3"> 3 </option>
                            <option value="4"> 4 </option>
                            <option value="5" selected> 5 </option>';
                            }
                            echo 
              
               ' 
            </select>
            <input type="submit" value="SetPriority"> 
            </form>
            <input type="hidden" value="' .$row[0]. '">
            </li>';
            
        }
    }
      ?>
      </ul>
    </div>
  <script src="js-to-do-list.js"></script>
  <script>

  </script>

  </body>
    </html>
    
